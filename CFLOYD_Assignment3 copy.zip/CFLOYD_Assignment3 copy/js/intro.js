var introState = {
    
    create: function() {
        
        //display the name of the game
        var nameLabel = game.add.text(80,80,'Intro',{font: '25px Arial',fill: '#ffffff'});
        
        //give the player instructions
        var startLabel = game.add.text(80,game.world.height-80,'press the "W" key to start', {font: '25px Arial', fill: '#ffffff'});
        
        game.add.sprite(0,0,'introPic');
        
        //define the spacebar key
        var spacekey = game.input.keyboard.addKey(Phaser.Keyboard.SPACEBAR);
        
        //when the player presses the W key, call start function
        spacekey.onDown.addOnce(this.start, this);
        
        
        
    },
    
    //start function calls the play state
    start: function(){
        
        game.state.start('park');
        
    }
    
}